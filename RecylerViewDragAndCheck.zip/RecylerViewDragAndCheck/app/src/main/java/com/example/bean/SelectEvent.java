package com.example.bean;
public class SelectEvent {
    private int size;

    public SelectEvent(int size) {
        this.size = size;
    }

    public int getSize() {
        return size;
    }
}
