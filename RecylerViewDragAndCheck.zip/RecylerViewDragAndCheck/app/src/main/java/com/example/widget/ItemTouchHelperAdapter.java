package com.example.widget;

public interface ItemTouchHelperAdapter {
    // Called when an item has been dragged far enough to trigger a move. This is called every time
    boolean onItemMove(int fromPosition, int toPosition);
    //Called when an item has been dismissed by a swipe
    void onItemDismiss(int position);
}
